//execute during the request/response cycle.
//Error Handler made


const errorHandler = (err, req, res, next) => {
//if statuscode show else show 500
    const statusCode = res.statusCode ?  res.statusCode: 500

    res.status(statusCode)
//stack trace gives additional information in development mood
    res.json({
        message: err.message, 
        stack: process.env.NODE_ENV == `prduction` ? null : err.stack
    })
}


module.exports  = {errorHandler}