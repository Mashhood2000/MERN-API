const express = require('express')
const dotenv = require('dotenv').config()
const connectDB = require(`./config/db`)
const  port = process.env.PORT || 5000
connectDB()
const {errorHandler} = require(`./middleware/errorMiddleware`)
const app = express()
//middle ware added to accept json and url encoded format from body from postman.
app.use(express.json())
app.use(express.urlencoded({extended: false}))
//mw

app.use(`/api/goals`, require(`./routes/goalRoutes`))
app.use(`/api/users`, require(`./routes/userRoutes`))

//using it from Middleware error handlers
app.use(errorHandler)
app.listen(port, () => console.log(`server started on port ${port}`))



